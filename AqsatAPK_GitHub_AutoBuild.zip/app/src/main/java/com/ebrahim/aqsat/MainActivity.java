package com.ebrahim.aqsat;
import android.app.*;import android.os.*;import android.widget.*;
public class MainActivity extends Activity{
 EditText phone,pin,cost,sale; TextView status,result; boolean logged=false;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
 phone=findViewById(R.id.loginPhone);pin=findViewById(R.id.loginPin);cost=findViewById(R.id.cost);sale=findViewById(R.id.sale);status=findViewById(R.id.status);result=findViewById(R.id.result);
 findViewById(R.id.login).setOnClickListener(v->login());findViewById(R.id.calc).setOnClickListener(v->calc());}
 void login(){if(phone.getText().toString().equals("01551160100")&&pin.getText().toString().equals("00000")){logged=true;status.setText("تم الدخول: المدير إبراهيم الشرقاوي");}else status.setText("رقم الهاتف أو الرقم السري غير صحيح");}
 void calc(){if(!logged){status.setText("سجل الدخول أولاً");return;}double c=num(cost),s=num(sale);result.setText("ربح العملية: "+(s-c)+" جنيه");}
 double num(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
}